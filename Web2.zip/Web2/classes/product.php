<?php
$filepath = realpath(dirname(__FILE__));
include_once($filepath . '/../lib/database.php');
include_once($filepath . '/../helpers/format.php');
?>

<?php

class product
{
    private $db;
    private $fm;
    public function __construct()
    {
        $this->db = new Database();
        $this->fm = new Format();
    }


    // Thêm sản phẩm 
    public function insert_product($data, $files)
    {


        $productName = mysqli_real_escape_string($this->db->link, $data['productName']);
        $price = mysqli_real_escape_string($this->db->link, $data['price']);
        // $image = mysqli_real_escape_string($this->db->link, $data['image']);
        $product_desc = mysqli_real_escape_string($this->db->link, $data['product_desc']);
        // $productName = mysqli_real_escape_string($this->db->link, $data['productName']);
        // kiểm tra và lấy hình ảnh cho vào folder uploads


        $permited  = array('jpg', 'jpeg', 'png', 'gif');
        $file_name = $_FILES['image']['name'];
        $file_size = $_FILES['image']['size'];
        $file_temp = $_FILES['image']['tmp_name'];

        $div = explode('.', $file_name);
        $file_ext = strtolower(end($div));
        $unique_image = substr(md5(time()), 0, 10) . '.' . $file_ext;
        $uploaded_image = "uploads/" . $unique_image;



        if ($productName == "" || $product_desc == "" || $price == "" || $file_name == "") {
            $alert = "Bạn không được để trống các trường";
            return $alert;
        } else {
            move_uploaded_file($file_temp, $uploaded_image);
            $query = "INSERT INTO tbl_product (productName, product_desc, price, image) VALUES ('$productName', '$product_desc', '$price', '$unique_image')";
            $result = $this->db->insert($query);

            if ($result) {
                $alert = "Thêm sản phẩm thành công";
                return $alert;
            } else {
                $alert = "Thêm thất bại";
                return $alert;
            }
        }
    }


    //Hiển thị sản phẩm 
    public function show_product()
    {
        $query = "SELECT * FROM tbl_product order by productid desc";
        // $query = "

        // SELECT p.*,c.catName, b.brandName

        // FROM tbl_product as p,tbl_category as c, tbl_brand as b where p.catId = c.catId 

        // AND p.brandId = b.brandId 

        // order by p.productId desc";

        // $query = "

        // 	SELECT tbl_product.*, tbl_category.catName, tbl_brand.brandName 

        // 	FROM tbl_product INNER JOIN tbl_category ON tbl_product.catId = tbl_category.catId 

        // 	INNER JOIN tbl_brand ON tbl_product.brandId = tbl_brand.brandId 

        // 	order by tbl_product.productId desc";

        // // $query = "SELECT * FROM tbl_product order by productId desc";

        $result = $this->db->select($query);
        return $result;
    }

    //sửa sản phẩm 
    public function update_product($data, $files, $id)
    {


        $productName = mysqli_real_escape_string($this->db->link, $data['productName']);
        $price = mysqli_real_escape_string($this->db->link, $data['price']);
        // $image = mysqli_real_escape_string($this->db->link, $data['image']);
        $product_desc = mysqli_real_escape_string($this->db->link, $data['product_desc']);
        // $productName = mysqli_real_escape_string($this->db->link, $data['productName']);
        // kiểm tra và lấy hình ảnh cho vào folder uploads


        $permited  = array('jpg', 'jpeg', 'png', 'gif');
        $file_name = $_FILES['image']['name'];
        $file_size = $_FILES['image']['size'];
        $file_temp = $_FILES['image']['tmp_name'];

        $div = explode('.', $file_name);
        $file_ext = strtolower(end($div));
        $unique_image = substr(md5(time()), 0, 10) . '.' . $file_ext;
        $uploaded_image = "uploads/" . $unique_image;


        if ($productName == "" || $product_desc == "" || $price == "") {
            $alert = "Bạn không được để trống các trường";
            return $alert;
        } else {
            if (!empty($file_name)) {
                //Nếu người dùng chọn ảnh
                if ($file_size > 1000000000) {
                    $alert = "Bạn phải chọn ảnh nhỏ hơn 2MB!";
                    return $alert;
                } else if (in_array($file_ext, $permited) === false) {
                    $alert = "<span class='success'>Bạn chỉ có thể tải lên:-" . implode(', ', $permited) . "</span>";
                    return $alert;
                }
                move_uploaded_file($file_temp, $uploaded_image);
                // $query = "UPDATE `tbl_product` SET `productName` = '$productName', `product_desc` = 'product_desc', `price` = '$price', `image` = '$unique_image' WHERE `tbl_product`.`productid` = '$id'";
                // UPDATE `tbl_product` SET `productName` = 'burgerc', `product_desc` = 'ấdadsac', `price` = '1000000', `image` = 'f805ac8bd6.png' WHERE `tbl_product`.`productid` = 9;
                $query = "UPDATE tbl_product SET
					productName = '$productName',
					product_desc = '$product_desc',
					price = '$price', 
					image = '$unique_image'
					WHERE productid = '$id'";
            } else {
                //Nếu người dùng không chọn ảnh
                $query = "UPDATE tbl_product SET
					productName = '$productName',
					product_desc = '$product_desc',
					price = '$price'
					WHERE productid = '$id'";
            }
            $result = $this->db->update($query);
            if ($result) {
                $alert = "Đã cập nhật sản phẩm thành công";
                return $alert;
            } else {
                $alert = "Sản phẩm được cập nhật không thành công";
                return $alert;
            }
        }
    }
    public function getproductbyid($id)
	{
		$query = "SELECT * FROM tbl_product where productId = '$id'";
		$result = $this->db->select($query);
		return $result;
	}

    //xóa sản phẩm 
    public function del_product($id)
	{
		$query = "DELETE FROM tbl_product where productid = '$id'";
		$result = $this->db->delete($query);
		if ($result) {
			$alert = "<span class='success'>Sản phẩm đã được xóa thành công</span>";
			return $alert;
		} else {
			$alert = "<span class='error'>Sản phẩm bị xóa không thành công</span>";
			return $alert;
		}
	}

    // hiển thị sản phẩm trang index;
    public function show_productindex($query)
    {
       // $query = "SELECT * FROM tbl_product order by productid desc";
        $result = $this->db->select($query);
        return $result;
    }

    //lấy ra sản phẩm dựa vào id sản phầm từ trang index
    public function get_details($id)
    {
        $query = "SELECT * FROM tbl_product where productid = $id";
        // echo $query ; exit();
       
        $result = $this->db->select($query);
        return $result;
    }
}

?>


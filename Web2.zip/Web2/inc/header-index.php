    <?php
    include 'lib/session.php';
    Session::init();
    ?>
    <?php

    include 'lib/database.php';
    include 'helpers/format.php';

    spl_autoload_register(function ($class) {
        include_once "classes/" . $class . ".php";
    });


    $db = new Database();
    $fm = new Format();
    $ct = new cart();
    $cs = new customer();
    $product = new product();


    ?>
    <?php
    header("Cache-Control: no-cache, must-revalidate");
    header("Pragma: no-cache");
    header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
    header("Cache-Control: max-age=2592000");

    ?>

    <body >
        <header style="padding-bottom: 6em">
                 <div class="logo" style="    background-color: #000;
    border-radius: 10px;box-shadow:  1rem 0rem 1rem 1rem white">
			<img src="https://img.freepik.com/free-vector/burger-logo-template_441059-21.jpg?w=2000" id='logo1' style="width: 65px; height : 60px;    margin: 4px;     position: absolute;">
            <h1 class="logo-text" style="padding-left: 2em;"> <span>SHOP</span> BURGER</h1>
        </div>
            <i class="fa fa-bars menu-toggle"></i>
            <ul class="nav">
                <li><a href="index.php" style="border-right: solid #fff 2px">Home</a></li>
                <li><a href="#" style="border-right: solid #fff 2px">About</a></li>

                <?php
                $login_check = Session::get('customer_login'); 
			if($login_check==false){
				echo '';
			}else{
				echo '<li><a href="profile.php" style="border-right: solid #fff 2px" >Khách hàng</a></li>';
			}
                ?>
                
                <li><a href="#" style="border-right: solid #fff 2px">Shop</a></li>
                <li><a href="./cart.php" style="border-right: solid #fff 2px"><i class="fas fa-shopping-cart"></i>
                        <?php
                        $check_cart = $ct->check_cart();
                        if ($check_cart) {
                           		// $sum = Session::get("sum");
                                    // echo $sum;
                            $qty = Session::get("qty");
                            echo $qty;
                             }else{
                             echo '0';
                        }

                        ?></a></li>
                <!-- <li><a href="#">Sign Up</a></li>
            <li><a href="#">Login</a></li> -->
                <li>
                    <a href="#" style="color: blue" style="z-index: 99">
                        
						<?php
							if(isset($_SESSION['customer_id'])){
							
								echo '<style>
							
								</style>';
								echo '<i style="color : red;" class="fas fa-user"></i>';
						
									echo " ".$_SESSION['customer_name']." ";
								echo '     <i style="color:red;" class="fa fa-chevron-down" style="font-size: .8em;"></i>';
							}else{
								echo '<i class="fas fa-user"></i>';
                      echo  ' Log In ';
								echo'     <i class="fa fa-chevron-down" style="font-size: .8em;"></i>';
							}
							?>
                   
                    </a>
                    <?php 
				if(isset($_GET['customer_id'])){
					$customer_id = $_GET['customer_id'];
					$delCart = $ct->del_all_data_cart();
					// $delCompare = $ct->del_compare($customer_id);
					Session::destroy();
				}
			?>
                    <ul>
                        <?php
                        $login_check = Session::get('customer_login');
                        if ($login_check == false) {
                            echo '<li><a href="login.php">Login</a></li></ul>';
                        } else {
                            echo '<li><a href="?customer_id='.Session::get('customer_id').'" style="font">Logout</a></li></ul>';  
                        }
                        ?>
                        <!-- <li><a href="#">Đăng Xuất</a></li> -->
                        <!-- <li><a href="login.php" class="logout">Sign Up</a></li> -->
                   
                </li>
            </ul>
        </header>


        
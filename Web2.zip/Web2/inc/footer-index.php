<!-- footer -->
<div class="footer" style="    padding-left: 100px;">
        <div class="footer-content">
            <div class="footer-section about">
			
                <h1 class="logo-text"><span>SHOP</span> BURGER</h1>
                <p>
                    Cảm ơn bạn đã xem được dòng ghi này nếu bạn là người cho điểm hẫy cho điểm nương tay
                    và nhẹ nhàng với người mà bạn được cho điểm vì biết đâu 1 điểm của bạn có để ảnh hưởng 
                    đến nữa tháng lương mà ba mẹ phụ cấp cho mình đấy. Chân thành cảm ơn !!!
                </p>
                <div class="contact">
                    <span class="fas fa-phone"> <i>&nbsp; 0981-biết thế thôi nhé</i></span>
                    <span class="fas fa-envelope"> <i>&nbsp; phamvantan@-biết thế thôi nhé</i></span>
                </div>
                <div class="socials">
                    <a href="#"><i class="fab fa-facebook"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-youtube"></i></a>
                </div>
            </div>
            <div class="footer-section links">
                <h2>Quick Links</h2>
                <br>
                <ul>
                    <a href="#">
                        <li>Events</li>
                    </a>
                    <a href="#">
                        <li>Events</li>
                    </a>
                    <a href="#">
                        <li>Events</li>
                    </a>
                    <a href="#">
                        <li>Events</li>
                    </a>
                    <a href="#">
                        <li>Events</li>
                    </a>
                    <a href="#">
                        <li>Events</li>
                    </a>
                </ul>
            </div>
            <div class="footer-section contact-form">
                <h2>Contact us</h2>
                <br>
                <form action="index.html" method="POST">
                    <input type="email" name="email" class="text-input contact-input" placeholder="Your email addres ....">
                    <br>
                    <textarea name="message"  class="text-input contact-input" placeholder="Your message......."></textarea><br>
                    <button class="btn btn-big">
                        <i class="fas fa-envelope"></i>
                        Send
                    </button>
                </form>
            </div>
        </div>
        <div class="footer-bottom">
            &copy; phamvantan.com | Designed by Văn Tân official
        </div>
    </div>
    <!-- footer -->


    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
        integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script defer src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>
    <script src="./js/scripts.js"></script>
</body>

</html>
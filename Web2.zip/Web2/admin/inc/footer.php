
    <div class="clear-both"></div>
    </div>
    </div>
    <div id="admin-footer">
        <div class="container">
            <div class="left-panel">
                @2021 Phạm Văn Tân - Lý thế Minh
            </div>
            <div class="right-panel">
                <a target="_blank" href="https://www.facebook.com/tuquyen.nambac.96" title="Facebook Andn Training"><i class="fab fa-facebook"></i></a>
                <a target="_blank" href="#" title="Youtube Andn Training Channel"><i class="fab fa-youtube"></i></a>
            </div>
            <div class="clear-both"></div>
        </div>
    </div>

</body>
</html>
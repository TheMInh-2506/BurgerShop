<?php
include '../classes/adminlogin.php';

?>
<?php
$class = new adminlogin();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $adminUser = $_POST['adminUser'];
    $adminPass = md5($_POST['adminPass']);

    $login_check = $class->login_admin($adminUser,$adminPass);
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cửa Hàng Hamburger</title>
    <style>
		html{
				background-image: url("../img/pb-beer-1513436-1600.jpg");
			  text-decoration: none;
			}
        .box-content {
            margin: 0 auto;
            width: 800px;
            border: 1px solid #ccc;
            text-align: center;
            padding: 20px;
        }

        #user_login form {
            width: 200px;
            margin: 40px auto;
        }

        #user_login form input {
            margin: 5px 0;
        }
    </style>
</head>

<body>
    <div id="user_login" class="box-content">
        <h1>Đăng nhập tài khoản</h1>
        <form action="./login.php" method="post">
        <span>
            <?php
            if(isset($login_check)){
                echo $login_check;
            }
            ?>
        </span>
            <label>Username</label></br>
            <input type="text" name="adminUser" value="" /><br />
            <label>Password</label></br>
            <input type="password" name="adminPass" value="" /></br>
            <br>
            <input type="submit" value="Đăng nhập" />
        </form>
    </div>
</body>

</html>
// JavaScript Document
//$(document).ready(function() {
//   $('#regis').click(function(event) {
//      // $('#form-login').animate({marginLeft: -300,opacity: 0});
//      // $('#form-dangky').animate({marginLeft: 0,opacity: 1});
//      $('.login').style.display="block";
//      $('.login').removeClass('hidden');
//   });
//	
//});

function loadregis()
{
	document.getElementById("form-dangky").style.display="block";
	document.getElementById("form-login").style.display="none";
}
function loadlogin()
{
	document.getElementById("form-dangky").style.display="none";
	document.getElementById("form-login").style.display="block";
}
$(window).load(function() {
  $('.flexslider').flexslider({
    animation: "slide"
  });
});